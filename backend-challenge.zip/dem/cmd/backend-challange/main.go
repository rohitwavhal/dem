package main

import (
	"fmt"
	"net/http"

	"github.com/rohitwavhal/dem/internal/matrix"
)

// Run with
//		go run .
// Send request with:
//		curl -F 'file=@/path/matrix.csv' "localhost:8080/echo"

func main() {

	matrixCtx := matrix.New()

	http.HandleFunc("/echo", matrixCtx.EchoHandler)
	http.HandleFunc("/invert", matrixCtx.InvertHandler)
	http.HandleFunc("/flatten", matrixCtx.FlattenHandler)
	http.HandleFunc("/sum", matrixCtx.SumHandler)
	http.HandleFunc("/multiply", matrixCtx.MultiplyHandler)

	fmt.Println("Server started at :8080")

	http.ListenAndServe(":8080", nil)
}
