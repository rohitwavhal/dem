package helper

import (
	"encoding/csv"
	"encoding/json"
	"mime/multipart"
	"net/http"
	"strconv"

	"github.com/rohitwavhal/dem/pkg/errcodes"
	"github.com/rohitwavhal/dem/pkg/resterrors"
)

// func parseCSV(file multipart.File) ([][]int, error) {
// 	reader := csv.NewReader(file)
// 	rows, err := reader.ReadAll()
// 	if err != nil {
// 		return nil, err
// 	}

// 	matrix := make([][]int, len(rows))
// 	for i, row := range rows {
// 		matrix[i] = make([]int, len(row))
// 		for j, val := range row {
// 			matrix[i][j], err = strconv.Atoi(val)
// 			if err != nil {
// 				return nil, err
// 			}
// 		}
// 	}

// 	return matrix, nil
// }

// func ParseFile(r *http.Request) ([][]int, error) {
// 	file, _, err := r.FormFile("file")
// 	if err != nil {
// 		return nil, err
// 	}
// 	defer file.Close()

// 	return parseCSV(file)
// }

func parseCSV(file multipart.File) ([][]int, error) {
	reader := csv.NewReader(file)
	rows, err := reader.ReadAll()
	if err != nil {
		return nil, &resterrors.Error{
			Message:    "invalid CSV format",
			Code:       errcodes.MATRIX0002,
			StatusCode: http.StatusBadRequest,
			Op:         "parseCSV",
			Err:        err,
		}
	}

	if len(rows) == 0 {
		return nil, &resterrors.Error{
			Message:    "empty matrix",
			Code:       errcodes.MATRIX0003,
			StatusCode: http.StatusBadRequest,
			Op:         "parseCSV",
		}
	}

	matrix := make([][]int, len(rows))
	rowLen := len(rows[0])

	for i, row := range rows {
		if len(row) != rowLen {
			return nil, &resterrors.Error{
				Message:    "matrix rows have inconsistent lengths",
				Code:       errcodes.MATRIX0004,
				StatusCode: http.StatusBadRequest,
				Op:         "parseCSV",
			}
		}
		matrix[i] = make([]int, len(row))
		for j, val := range row {
			matrix[i][j], err = strconv.Atoi(val)
			if err != nil {
				return nil, &resterrors.Error{
					Message:    "invalid CSV format",
					Code:       errcodes.MATRIX0002,
					StatusCode: http.StatusBadRequest,
					Op:         "parseCSV",
					Err:        err,
				}
			}
		}
	}

	if len(matrix) != rowLen {
		return nil, &resterrors.Error{
			Message:    "matrix must be square",
			Code:       errcodes.MATRIX0005,
			StatusCode: http.StatusBadRequest,
			Op:         "parseCSV",
		}
	}

	return matrix, nil
}

func ParseFile(r *http.Request) ([][]int, error) {
	file, _, err := r.FormFile("file")
	if err != nil {
		return nil, &resterrors.Error{
			Message:    "unable to read file",
			Code:       errcodes.MATRIX0001,
			StatusCode: http.StatusBadRequest,
			Op:         "ParseFile",
			Err:        err,
		}
	}
	defer file.Close()

	return parseCSV(file)
}

func WithError(w http.ResponseWriter, r *http.Request, err error) {
	w.Header().Add("Content-Type", "application/json;charset=UTF-8")

	switch err.(type) {
	case *resterrors.Error:
		if e, ok := err.(*resterrors.Error); ok {
			w.WriteHeader(e.StatusCode)
		}
		json.NewEncoder(w).Encode(err)

	default:
		w.WriteHeader(http.StatusInternalServerError)
	}

}
