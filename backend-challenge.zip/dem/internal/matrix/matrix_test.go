package matrix

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/golang/mock/gomock"
	"github.com/rohitwavhal/dem/internal/matrix/mocks"
	"github.com/stretchr/testify/assert"
)

var matrixCtx matrixHandlerContext
var mockMatrixSvcCtx *mocks.MockIMatrixContext

func setup(t *testing.T) {
	mockctrl := gomock.NewController(t)
	defer mockctrl.Finish()

	mockMatrixSvcCtx = mocks.NewMockIMatrixContext(mockctrl)

	matrixCtx = matrixHandlerContext{
		matrixSvcCtx: mockMatrixSvcCtx,
	}

}

func Test_matrixHandlerContext_EchoHandler(t *testing.T) {
	setup(t)

	req, _ := createMultipartRequest("/echo", "matrix.csv")
	req2, _ := http.NewRequest("GET", "/echo", nil)

	type args struct {
		r *http.Request
	}
	tests := []struct {
		name         string
		m            *matrixHandlerContext
		args         args
		wantResponce string
		wantCode     int
		err          error
	}{
		{
			name: "Should return 200 with matrix data",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode:     200,
			wantResponce: "1,2,3,4,5,6,7,8,9",
		},
		{
			name: "Should return 500",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode: 500,
			err:      errors.New("interal server error"),
		},
		{
			name: "Should return 400 if no file in request",
			m:    &matrixCtx,
			args: args{
				r: req2,
			},
			wantCode: 400,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockMatrixSvcCtx.EXPECT().MatrixToString(gomock.Any()).Return("1,2,3,4,5,6,7,8,9", tt.err)
			w := httptest.NewRecorder()
			tt.m.EchoHandler(w, tt.args.r)
			assert.Equal(t, tt.wantCode, w.Code)
		})
	}
}

func Test_matrixHandlerContext_InvertHandler(t *testing.T) {
	setup(t)

	req, _ := createMultipartRequest("/echo", "matrix.csv")
	req2, _ := http.NewRequest("GET", "/echo", nil)

	type args struct {
		r *http.Request
	}
	tests := []struct {
		name         string
		m            *matrixHandlerContext
		args         args
		wantResponce string
		wantCode     int
		err          error
	}{
		{
			name: "Should return 200 with matrix data",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode:     200,
			wantResponce: "1,2,3,4,5,6,7,8,9",
		},
		{
			name: "Should return 500",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode: 500,
			err:      errors.New("interal server error"),
		},
		{
			name: "Should return 400 if no file in request",
			m:    &matrixCtx,
			args: args{
				r: req2,
			},
			wantCode: 400,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockMatrixSvcCtx.EXPECT().InvertMatrix(gomock.Any()).Return([][]int{}, tt.err)
			mockMatrixSvcCtx.EXPECT().MatrixToString(gomock.Any()).Return("1,2,3,4,5,6,7,8,9", tt.err)
			w := httptest.NewRecorder()
			tt.m.InvertHandler(w, tt.args.r)
			assert.Equal(t, tt.wantCode, w.Code)
			if tt.wantCode == 200 {
				assert.Equal(t, tt.wantResponce, w.Body.String())
			}
		})
	}
}

func Test_matrixHandlerContext_FlattenHandler(t *testing.T) {
	setup(t)

	req, _ := createMultipartRequest("/flatten", "matrix.csv")
	req2, _ := http.NewRequest("GET", "/flatten", nil)

	type args struct {
		r *http.Request
	}
	tests := []struct {
		name         string
		m            *matrixHandlerContext
		args         args
		wantResponce string
		wantCode     int
		err          error
	}{
		{
			name: "Should return 200 with matrix data",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode:     200,
			wantResponce: "1,2,3,4,5,6,7,8,9",
		},
		{
			name: "Should return 500",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode: 500,
			err:      errors.New("interal server error"),
		},
		{
			name: "Should return 400 if no file in request",
			m:    &matrixCtx,
			args: args{
				r: req2,
			},
			wantCode: 400,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockMatrixSvcCtx.EXPECT().FlattenMatrix(gomock.Any()).Return([]int{1, 2, 3, 4, 5, 6, 7, 8, 9}, tt.err)
			w := httptest.NewRecorder()
			tt.m.FlattenHandler(w, tt.args.r)
			assert.Equal(t, tt.wantCode, w.Code)
			if tt.wantCode == 200 {
				assert.Equal(t, tt.wantResponce, w.Body.String())
			}
		})
	}
}

func Test_matrixHandlerContext_SumHandler(t *testing.T) {
	setup(t)

	req, _ := createMultipartRequest("/sum", "matrix.csv")
	req2, _ := http.NewRequest("GET", "/sum", nil)

	type args struct {
		r *http.Request
	}
	tests := []struct {
		name         string
		m            *matrixHandlerContext
		args         args
		wantResponce string
		wantCode     int
		err          error
	}{
		{
			name: "Should return 200 with matrix data",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode:     200,
			wantResponce: "45",
		},
		{
			name: "Should return 500",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode: 500,
			err:      errors.New("interal server error"),
		},
		{
			name: "Should return 400 if no file in request",
			m:    &matrixCtx,
			args: args{
				r: req2,
			},
			wantCode: 400,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockMatrixSvcCtx.EXPECT().SumMatrix(gomock.Any()).Return(45, tt.err)
			w := httptest.NewRecorder()
			tt.m.SumHandler(w, tt.args.r)
			assert.Equal(t, tt.wantCode, w.Code)
			if tt.wantCode == 200 {
				assert.Equal(t, tt.wantResponce, w.Body.String())
			}
		})
	}
}

func Test_matrixHandlerContext_MultiplyHandler(t *testing.T) {
	setup(t)

	req, _ := createMultipartRequest("/multiply", "matrix.csv")
	req2, _ := http.NewRequest("GET", "/multiply", nil)

	type args struct {
		r *http.Request
	}
	tests := []struct {
		name         string
		m            *matrixHandlerContext
		args         args
		wantResponce string
		wantCode     int
		err          error
	}{
		{
			name: "Should return 200 with matrix data",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode:     200,
			wantResponce: "45",
		},
		{
			name: "Should return 500",
			m:    &matrixCtx,
			args: args{
				r: req,
			},
			wantCode: 500,
			err:      errors.New("interal server error"),
		},
		{
			name: "Should return 400 if no file in request",
			m:    &matrixCtx,
			args: args{
				r: req2,
			},
			wantCode: 400,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockMatrixSvcCtx.EXPECT().MultiplyMatrix(gomock.Any()).Return(45, tt.err)
			w := httptest.NewRecorder()
			tt.m.MultiplyHandler(w, tt.args.r)
			assert.Equal(t, tt.wantCode, w.Code)
			if tt.wantCode == 200 {
				assert.Equal(t, tt.wantResponce, w.Body.String())
			}
		})
	}
}

func createMultipartRequest(url, filePath string) (*http.Request, error) {
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)

	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to open file: %w", err)
	}
	defer file.Close()

	part, err := writer.CreateFormFile("file", filepath.Base(file.Name()))
	if err != nil {
		return nil, fmt.Errorf("failed to create form file: %w", err)
	}

	_, err = io.Copy(part, file)
	if err != nil {
		return nil, fmt.Errorf("failed to copy file content: %w", err)
	}

	err = writer.Close()
	if err != nil {
		return nil, fmt.Errorf("failed to close writer: %w", err)
	}

	request, err := http.NewRequest("POST", url, body)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	request.Header.Set("Content-Type", writer.FormDataContentType())

	return request, nil
}
