package matrix

import (
	"strconv"
	"strings"
)

type MatrixContext struct{}

func NewMatrixContext() *MatrixContext {
	return &MatrixContext{}
}

func (m *MatrixContext) MatrixToString(matrix [][]int) (string, error) {
	response := make([]string, len(matrix))
	for i, row := range matrix {
		strRow := make([]string, len(row))
		for j, val := range row {
			strRow[j] = strconv.Itoa(val)
		}
		response[i] = strings.Join(strRow, ",")
	}

	return strings.Join(response, "\n"), nil
}

func (m *MatrixContext) InvertMatrix(matrix [][]int) ([][]int, error) {
	n := len(matrix)
	inverted := make([][]int, n)
	for i := range inverted {
		inverted[i] = make([]int, n)
	}

	for i := range matrix {
		for j := range matrix[i] {
			inverted[j][i] = matrix[i][j]
		}
	}

	return inverted, nil
}

func (m *MatrixContext) FlattenMatrix(matrix [][]int) ([]int, error) {
	var flat []int
	for _, row := range matrix {
		flat = append(flat, row...)
	}

	return flat, nil
}

func (m *MatrixContext) SumMatrix(matrix [][]int) (int, error) {
	sum := 0
	for _, row := range matrix {
		for _, val := range row {
			sum += val
		}
	}

	return sum, nil
}

func (m *MatrixContext) MultiplyMatrix(matrix [][]int) (int, error) {
	product := 1
	for _, row := range matrix {
		for _, val := range row {
			product *= val
		}
	}

	return product, nil
}
