package matrix

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/rohitwavhal/dem/internal/helper"
)

type matrixHandlerContext struct {
	matrixSvcCtx IMatrixContext
}

func New() *matrixHandlerContext {
	svcCtx := NewMatrixContext()

	return &matrixHandlerContext{
		matrixSvcCtx: svcCtx,
	}
}

// EchoHandler: Returns the matrix as a string in matrix format.
func (m *matrixHandlerContext) EchoHandler(w http.ResponseWriter, r *http.Request) {
	matrix, err := helper.ParseFile(r)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	response, err := m.matrixSvcCtx.MatrixToString(matrix)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	w.Write([]byte(response))
}

// InvertHandler: Returns the matrix as a string in matrix format where the columns and rows are inverted
func (m *matrixHandlerContext) InvertHandler(w http.ResponseWriter, r *http.Request) {
	matrix, err := helper.ParseFile(r)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	inverted, err := m.matrixSvcCtx.InvertMatrix(matrix)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	response, err := m.matrixSvcCtx.MatrixToString(inverted)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	w.Write([]byte(response))
}

// InvertHandler: Returns the matrix as a 1 line string, with values separated by commas.
func (m *matrixHandlerContext) FlattenHandler(w http.ResponseWriter, r *http.Request) {
	matrix, err := helper.ParseFile(r)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	flat, err := m.matrixSvcCtx.FlattenMatrix(matrix)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	strFlat := make([]string, len(flat))
	for i, val := range flat {
		strFlat[i] = strconv.Itoa(val)
	}

	w.Write([]byte(strings.Join(strFlat, ",")))
}

// FlattenHandler: Return the sum of the integers in the matrix
func (m *matrixHandlerContext) SumHandler(w http.ResponseWriter, r *http.Request) {
	matrix, err := helper.ParseFile(r)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	sum, err := m.matrixSvcCtx.SumMatrix(matrix)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	w.Write([]byte(strconv.Itoa(sum)))
}

// MultiplyHandler: Return the product of the integers in the matrix
func (m *matrixHandlerContext) MultiplyHandler(w http.ResponseWriter, r *http.Request) {
	matrix, err := helper.ParseFile(r)
	if err != nil {
		helper.WithError(w, r, err)
		return
	}

	product, err := m.matrixSvcCtx.MultiplyMatrix(matrix)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write([]byte(strconv.Itoa(product)))
}
