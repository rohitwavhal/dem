package matrix

type IMatrixContext interface {
	MatrixToString(matrix [][]int) (string, error)
	InvertMatrix(matrix [][]int) ([][]int, error)
	FlattenMatrix(matrix [][]int) ([]int, error)
	SumMatrix(matrix [][]int) (int, error)
	MultiplyMatrix(matrix [][]int) (int, error)
}
