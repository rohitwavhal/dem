package matrix

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestMatrixContext_MatrixToString(t *testing.T) {

	type args struct {
		matrix [][]int
	}
	tests := []struct {
		name    string
		m       *MatrixContext
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "Should return matrix in string format",
			m:    &MatrixContext{},
			args: args{
				matrix: [][]int{{1, 2, 3}, {4, 5, 6}, {7, 8, 9}},
			},
			want:    "1,2,3\n4,5,6\n7,8,9",
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.m.MatrixToString(tt.args.matrix)
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

func TestMatrixContext_InvertMatrix(t *testing.T) {
	type args struct {
		matrix [][]int
	}
	tests := []struct {
		name    string
		m       *MatrixContext
		args    args
		want    [][]int
		wantErr bool
	}{
		{
			name: "Should return inverted matrix",
			m:    &MatrixContext{},
			args: args{
				matrix: [][]int{{1, 2, 3}, {4, 5, 6}, {7, 8, 9}},
			},
			want: [][]int{{1, 4, 7}, {2, 5, 8}, {3, 6, 9}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.m.InvertMatrix(tt.args.matrix)
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

func TestMatrixContext_FlattenMatrix(t *testing.T) {
	type args struct {
		matrix [][]int
	}
	tests := []struct {
		name    string
		m       *MatrixContext
		args    args
		want    []int
		wantErr bool
	}{
		{
			name: "Should return flattened matrix",
			m:    &MatrixContext{},
			args: args{
				matrix: [][]int{{1, 2, 3}, {4, 5, 6}, {7, 8, 9}},
			},
			want:    []int{1, 2, 3, 4, 5, 6, 7, 8, 9},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.m.FlattenMatrix(tt.args.matrix)
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

func TestMatrixContext_SumMatrix(t *testing.T) {
	type args struct {
		matrix [][]int
	}
	tests := []struct {
		name    string
		m       *MatrixContext
		args    args
		want    int
		wantErr bool
	}{
		{
			name: "Should return sum of matrix",
			m:    &MatrixContext{},
			args: args{
				matrix: [][]int{{1, 2, 3}, {4, 5, 6}, {7, 8, 9}},
			},
			want:    45,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.m.SumMatrix(tt.args.matrix)
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

func TestMatrixContext_MultiplyMatrix(t *testing.T) {
	type args struct {
		matrix [][]int
	}
	tests := []struct {
		name    string
		m       *MatrixContext
		args    args
		want    int
		wantErr bool
	}{
		{
			name: "Should return product of matrix",
			m:    &MatrixContext{},
			args: args{
				matrix: [][]int{{1, 2, 3}, {4, 5, 6}, {7, 8, 9}},
			},
			want:    362880,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.m.MultiplyMatrix(tt.args.matrix)
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}
