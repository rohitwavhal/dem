package resterrors

import (
	"bytes"
	"fmt"
)

const (
	BadRequest          = "bad_request"
	Unauthorized        = "unauthorized"
	Forbidden           = "forbidden"
	NotFound            = "not_found"
	InternalServerError = "internal_server_error"
)

type Error struct {
	Message    string `json:"message"`
	Code       string `json:"code"`
	StatusCode int    `json:"statusCode"`
	Op         string `json:"-"`
	Err        error  `json:"-"`
}

func (e *Error) Error() string {
	var buf bytes.Buffer

	if e.Op != "" {
		fmt.Fprintf(&buf, "%s: ", e.Op)
	}

	//assumption is .. if we have Err, then we don't have code/message
	if e.Err != nil {
		buf.WriteString(e.Err.Error())
	} else {
		if e.Code != "" {
			fmt.Fprintf(&buf, "<%s> ", e.Code)
		}
		buf.WriteString(e.Message)
	}
	return buf.String()
}
