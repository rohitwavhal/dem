package errcodes

const (
	MATRIX0001 = "unable to read file"
	MATRIX0002 = "invalid CSV format"
	MATRIX0003 = "empty matrix"
	MATRIX0004 = "matrix rows have inconsistent lengths"
	MATRIX0005 = "matrix must be square"
)
